package hw2.agents.moveorder;

import java.util.LinkedList;
import java.util.List;

import hw2.chess.search.DFSTreeNode;

public class CustomMoveOrderer
{

	/**
	 * TODO: implement me!
	 * This method should perform move ordering. Remember, move ordering is how alpha-beta pruning gets part of its power from.
	 * You want to see nodes which are beneficial FIRST so you can prune as much as possible during the search (i.e. be faster)
	 * @param nodes. The nodes to order (these are children of a DFSTreeNode) that we are about to consider in the search.
	 * @return The ordered nodes.
	 * 
	 * MOVE TYPES:
	 * 
		public enum MoveType
		{

		CAPTUREMOVE, -> a move that captures a piece
		CASTLEMOVE, -> early game strategy to improve the king's safety
		MOVEMENTMOVE, -> moving a piece without capturing 
		PROMOTEPAWNMOVE, -> promoting a pawn to a more powerful piece
		ENPASSANTMOVE; -> pawn captures pawn

		
		}

	 */
	public static List<DFSTreeNode> order(List<DFSTreeNode> nodes)
	{
		// please replace this!
		//return DefaultMoveOrderer.order(nodes);
		
		    List<DFSTreeNode> captureNodes = new LinkedList<DFSTreeNode>();
		    List<DFSTreeNode> castleNodes = new LinkedList<DFSTreeNode>();
		    List<DFSTreeNode> movementNodes = new LinkedList<DFSTreeNode>();
		    List<DFSTreeNode> promotePawnNodes = new LinkedList<DFSTreeNode>();
		    List<DFSTreeNode> enPassantNodes = new LinkedList<DFSTreeNode>();
		    
		    for (DFSTreeNode node : nodes) {
		        if (node.getMove() != null) {
		            switch (node.getMove().getType()){
		                case CAPTUREMOVE:
		                    captureNodes.add(node);
		                    break;
		                case CASTLEMOVE:
		                    castleNodes.add(node);
		                    break;
		                case MOVEMENTMOVE:
		                    movementNodes.add(node);
		                    break;
		                case PROMOTEPAWNMOVE:
		                    promotePawnNodes.add(node);
		                    break;
		                case ENPASSANTMOVE:
		                    enPassantNodes.add(node);
		                    break;
		            }
		        } 
		        else {
		            movementNodes.add(node);
		        }
		    }
		    
		    // PRIORITIZING MOVES:
		    captureNodes.addAll(castleNodes);
		    captureNodes.addAll(promotePawnNodes);
		    captureNodes.addAll(enPassantNodes);
		    captureNodes.addAll(movementNodes);
		    
		    
		    
		    
		    return captureNodes;
		}

	}


