package hw2.agents.heuristics;

import hw2.chess.game.player.Player;
import hw2.chess.search.DFSTreeNode;

import java.util.List;
import java.util.Set;

import edu.cwru.sepia.util.Direction;
import hw2.agents.heuristics.DefaultHeuristics.DefensiveHeuristics;
import hw2.agents.heuristics.DefaultHeuristics.OffensiveHeuristics;
import hw2.chess.game.Board;
import hw2.chess.game.move.Move;
import hw2.chess.game.move.MoveType;
import hw2.chess.game.move.PromotePawnMove;
import hw2.chess.game.piece.Bishop;
import hw2.chess.game.piece.Knight;
import hw2.chess.game.piece.Pawn;
import hw2.chess.game.piece.Piece;
import hw2.chess.game.piece.PieceType;
import hw2.chess.game.piece.Queen;
import hw2.chess.game.piece.Rook;
import hw2.chess.utils.Coordinate;

public class CustomHeuristics
{
	
		/*
		 * same as the function in default heuristics but we prioritize attack on king
		 */
	
		public static int getOffensivePieceValueTotalSurroundingMaxPlayersKing(DFSTreeNode node)
		{
		    // what is the state of the pieces next to the opponent king? add up the values of the neighboring pieces
		    // positive value for friendly pieces and negative value for enemy pieces (will clamp at 0)
		    int maxPlayerKingSurroundingPiecesValueTotal = 0;

		    Piece kingPiece = node.getGame().getBoard().getPieces(DefaultHeuristics.getMaxPlayer(node), PieceType.KING).iterator().next();
		    Coordinate kingPosition = node.getGame().getCurrentPosition(kingPiece);
		    for(Direction direction : Direction.values())
		    {
		        Coordinate neighborPosition = kingPosition.getNeighbor(direction);
		        if(node.getGame().getBoard().isInbounds(neighborPosition) && node.getGame().getBoard().isPositionOccupied(neighborPosition))
		        {
		            Piece piece = node.getGame().getBoard().getPieceAtPosition(neighborPosition);
		            int pieceValue = Piece.getPointValue(piece.getType());
		            if(piece != null && kingPiece.isEnemyPiece(piece))
		            {
		                maxPlayerKingSurroundingPiecesValueTotal -= pieceValue;
		            } 
		            else if(piece != null && !kingPiece.isEnemyPiece(piece))
		            {
		                maxPlayerKingSurroundingPiecesValueTotal += pieceValue;
		            }
		        }
		    }
		    // kingSurroundingPiecesValueTotal cannot be < 0 b/c the utility of losing a game is 0, so all of our utility values should be at least 0
		    maxPlayerKingSurroundingPiecesValueTotal = Math.max(maxPlayerKingSurroundingPiecesValueTotal, 0);
		    
		    // Double the value of the pieces surrounding the king if it's our turn to move. 
		    // now we will prioritize attacking the opponent's king over other pieces
		    if (node.getGame().getCurrentPlayer() == DefaultHeuristics.getMaxPlayer(node)) {
		        maxPlayerKingSurroundingPiecesValueTotal *= 2;
		    }

		    return maxPlayerKingSurroundingPiecesValueTotal;
		
		}
		/*
		 *  same as getting clamped piece value method of the max player, but this time we do it for min player
		 */
		public static int getClampedPieceValueTotalSurroundingMinPlayersKing(DFSTreeNode node)
		{
		    // what is the state of the pieces next to the king? add up the values of the neighboring pieces
		    // positive value for friendly pieces and negative value for enemy pieces (will clamp at 0)
		    int minPlayerKingSurroundingPiecesValueTotal = 0;

		    Piece kingPiece = node.getGame().getBoard().getPieces(DefaultHeuristics.getMinPlayer(node), PieceType.KING).iterator().next();
		    Coordinate kingPosition = node.getGame().getCurrentPosition(kingPiece);
		    for(Direction direction : Direction.values())
		    {
		        Coordinate neighborPosition = kingPosition.getNeighbor(direction);
		        if(node.getGame().getBoard().isInbounds(neighborPosition) && node.getGame().getBoard().isPositionOccupied(neighborPosition))
		        {
		            Piece piece = node.getGame().getBoard().getPieceAtPosition(neighborPosition);
		            int pieceValue = Piece.getPointValue(piece.getType());
		            if(piece != null && kingPiece.isEnemyPiece(piece))
		            {
		                minPlayerKingSurroundingPiecesValueTotal += pieceValue; // change to plus instead of minus
		            } else if(piece != null && !kingPiece.isEnemyPiece(piece))
		            {
		                minPlayerKingSurroundingPiecesValueTotal -= pieceValue; // change to minus instead of plus
		            }
		        }
		    }
		    // kingSurroundingPiecesValueTotal cannot be < 0 b/c the utility of losing a game is 0, so all of our utility values should be at least 0
		    minPlayerKingSurroundingPiecesValueTotal = Math.max(minPlayerKingSurroundingPiecesValueTotal, 0);
		    return minPlayerKingSurroundingPiecesValueTotal;
		}
		/*
		 * difference in the Calmped piece value surrounding max and min player king
		 */
		public static int getClampedPieceValueDifference(DFSTreeNode node) {
			int a = CustomHeuristics.getClampedPieceValueTotalSurroundingMinPlayersKing(node);
			int b = DefaultHeuristics.DefensiveHeuristics.getClampedPieceValueTotalSurroundingMaxPlayersKing(node);
			return a - b;
		}

		/*
		 * difference in the total number of moves between the Max and Min player
		 */
		public static int getNumberOfMovesDifference(DFSTreeNode node)
		{
		    // Get the current player and opponent
		    Player currentPlayer = DefaultHeuristics.getMaxPlayer(node); 
		    Player opponent = DefaultHeuristics.getMinPlayer(node);
		    
		    // Get the number of legal moves for each player
		    int currentPlayerNumMoves = node.getGame().getAllMoves(currentPlayer).size();
		    int opponentNumMoves = node.getGame().getAllMoves(opponent).size();
		    
		    // Return the difference in number of moves
		    return currentPlayerNumMoves - opponentNumMoves;
		}
		/*
		 * the difference in the number of pieces 
		 */
		public static int getPieceCountDifference(DFSTreeNode node) {
		    int numPiecesMaxPlayer = node.getGame().getBoard().getPieces(DefaultHeuristics.getMaxPlayer(node)).size();
		    int numPiecesMinPlayer = node.getGame().getBoard().getPieces(DefaultHeuristics.getMinPlayer(node)).size();
		    return numPiecesMaxPlayer - numPiecesMinPlayer;
		}
		
		/*
		 * Difference in the number of pieces that are threatening Max player vs min player
		 */
		public static int getNumberOfPiecesThreateningDifference(DFSTreeNode node)
		{
			int numPiecesCurrentPlayerisThreatening = DefaultHeuristics.OffensiveHeuristics.getNumberOfPiecesMaxPlayerIsThreatening(node);
			int numPiecesOtherPlayerisThreatening = DefaultHeuristics.DefensiveHeuristics.getNumberOfPiecesThreateningMaxPlayer(node);
			return numPiecesCurrentPlayerisThreatening - numPiecesOtherPlayerisThreatening;
			
		}
		/*
		 * Get the number of capturing moves against the opponent's king 
		 */
		public static int getNumCapturingMovesAgainstOpponentKing(DFSTreeNode node)
	    {
			// we want to get the other player's king
	        Piece king = node.getGame().getBoard().getPieces(DefaultHeuristics.getMinPlayer(node), PieceType.KING).iterator().next();
	        // number of capture moves against opponent's king
	        List<Move> capturingMoves = king.getAllCaptureMoves(node.getGame());
	        int numCapturingMoves = capturingMoves.size();
	        return numCapturingMoves;
	    }
		
		
	/**
	 * TODO: implement me! The heuristics that I wrote are useful, but not very good for a good chessbot.
	 * Please use this class to add your heuristics here! I recommend taking a look at the ones I provided for you
	 * in DefaultHeuristics.java (which is in the same directory as this file)
	 */
	// these may involve board position, strategy, piece formation
	
	
	public static double getHeuristicValue(DFSTreeNode node){	
		
		// please replace this!
		int a = CustomHeuristics.getOffensivePieceValueTotalSurroundingMaxPlayersKing(node); 
		int b = CustomHeuristics.getNumberOfMovesDifference(node);
		int c = CustomHeuristics.getPieceCountDifference(node);
		int d = CustomHeuristics.getNumberOfPiecesThreateningDifference(node);
		int e = CustomHeuristics.getClampedPieceValueDifference(node);
		double f = DefaultHeuristics.getNonlinearPieceCombinationMaxPlayerHeuristicValue(node);
		//int g = CustomHeuristics.getNumCapturingMovesAgainstOpponentKing(node);
			
		return a + b + c + d + e + f ;//+ g;
	}

}



